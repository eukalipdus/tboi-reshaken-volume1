local DelugeOrb = {}
local enums = MilkshakeVol1.enums
local utility = MilkshakeVol1.utility
local game = Game()
local sfx = SFXManager()

DelugeOrb.Force = 52
DelugeOrb.Radius = 260
DelugeOrb.SpeedMultiplier = 2.25
DelugeOrb.WaterSpeed = 1
DelugeOrb.Timeout = 240
DelugeOrb.DamageTick = 2
DelugeOrb.DamageArea = 57
DelugeOrb.DamageMultiplier = 0.75
DelugeOrb.SplashTick = 8
DelugeOrb.DelayBetweenLasers = 7
DelugeOrb.SwirlScale = 0.8
DelugeOrb.SwirlAlpha = 0.8

local StopNextMusic = false
--[[
-- moved to utility
--- Written by Zamiel, technique created by im_tem, tweaked
function DelugeOrb.SetBlindfold(player, enabled)
	---Blindfold
    local challenge = Isaac.GetChallenge()
	print(player:CanShoot())
    if enabled and player:CanShoot() then
        game.Challenge = Challenge.CHALLENGE_SOLAR_SYSTEM
        player:UpdateCanShoot()
        game.Challenge = challenge
        player:TryRemoveNullCostume(NullItemID.ID_BLINDFOLD)
		utility:SetData(player, "SetBlind", true)
    elseif not enabled and utility:GetData(player, "SetBlind") then --if player:CanShoot() then
		if not player:CanShoot() then
			game.Challenge = Challenge.CHALLENGE_NULL
			player:UpdateCanShoot()
			game.Challenge = challenge
		end
		utility:SetData(player, "SetBlind", nil)
    end
end
--]]


function DelugeOrb.ExtraUse(lasers, double)
	double = double or 1
	for _, laser in pairs(lasers) do
		laser = laser:ToEffect()
		if utility:GetData(laser, "DelugeOrb") then
			laser:SetTimeout(laser.Timeout + (DelugeOrb.Timeout * double))
			laser:GetSprite():Play("Loop")
		end
	end
end

function DelugeOrb:onPEffectUpdate(player)
	if utility:GetData(player, "DelugeOrbUsed") then
		if #Isaac.FindByType(EntityType.ENTITY_EFFECT, EffectVariant.HUSH_LASER_UP) == 0 and #Isaac.FindByType(EntityType.ENTITY_EFFECT, enums.Effects.DELUGE_LASER) == 0 then
			utility:SetData(player, "DelugeOrbUsed", nil)
			utility:SetBlindfold(player, false)
			player:TryRemoveNullCostume(enums.Costumes.DELUGE_ORB)
			sfx:Stop(enums.Sounds.WATER_FLOW)
		else
			player.Velocity = player:GetMovementVector()*DelugeOrb.SpeedMultiplier
		end
	end
end
MilkshakeVol1:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, DelugeOrb.onPEffectUpdate)

function DelugeOrb:onWaterfallDownUpdate(effect)
	--local effectData = effect:GetData()
	if not utility:GetData(effect, "DelugeOrb") then return end
	if effect:GetSprite():IsFinished("End") then
		effect:Remove()
	end
	if effect:GetSprite():IsPlaying("End") then return end
	if effect:GetSprite():IsFinished("Start") then
		effect:GetSprite():Play("Loop")
	end
	local double = utility:GetData(effect, "DelugeOrb")
	local player = effect.Parent:ToPlayer()
	---flush effect
	if utility:GetData(effect, "DelugeFlushed") and effect.FrameCount == 1 then
		utility:SetData(effect, "DelugeFlushed", nil)
		player:UseActiveItem(CollectibleType.COLLECTIBLE_FLUSH, UseFlag.USE_NOANIM | UseFlag.USE_NOANNOUNCER | UseFlag.USE_MIMIC)
		sfx:Stop(SoundEffect.SOUND_FLUSH)
		local enemies = Isaac.FindInRadius(player.Position, 5000, EntityPartition.ENEMY)
		for _, enemy in pairs(enemies) do
			if utility:GetData(enemy, "DelugeFlushed") then
				enemy:ClearEntityFlags(EntityFlag.FLAG_FRIENDLY)
				utility:SetData(enemy, "DelugeFlushed", nil)
			end
		end

		TSIL.Utils.Functions.RunInFrames(function ()
			StopNextMusic = false
		end, 2)
	end
	---magnetite
	local attractForce = DelugeOrb.Force
	if double > 1 then
		attractForce = attractForce * 1.3
	end
	game:UpdateStrangeAttractor(effect.Position, DelugeOrb.Force, DelugeOrb.Radius * double)
	for _, pickup in pairs(Isaac.FindInRadius(effect.Position, DelugeOrb.Radius, EntityPartition.PICKUP)) do
		if pickup:ToPickup() then
			pickup.GridCollisionClass = GridCollisionClass.COLLISION_WALL
		end
	end
	effect.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ENEMIES
	effect.Velocity = (effect.Velocity + (player:GetAimDirection()):Resized(DelugeOrb.WaterSpeed)) * 0.9 --
	---water ripple
	if effect.FrameCount % DelugeOrb.SplashTick == 0 then
		local splash = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.WATER_RIPPLE, 0, effect.Position, Vector.Zero, effect):ToEffect()
		splash.SpriteScale = Vector.One * 3
	end
	---grid damage
	local grid = game:GetRoom():GetGridEntityFromPos(effect.Position)
	if grid and (grid:ToPoop() or grid:ToTNT()) then
		grid:Hurt(10)
	end
	---npc damage
	if effect.FrameCount % DelugeOrb.DamageTick == 0 then
		local dmg = 1 + (DelugeOrb.DamageMultiplier*MilkshakeVol1.utility:GetCurrentChapter())
		for _, enemy in pairs(Isaac.FindInRadius(effect.Position, DelugeOrb.DamageArea, EntityPartition.ENEMY)) do
			if enemy:ToNPC() then
				enemy:TakeDamage(dmg, DamageFlag.DAMAGE_IGNORE_ARMOR, EntityRef(player), 1)
			end
		end
	end
	---end of effect
	if effect.Timeout <= 1 then
		effect:GetSprite():Play("End")
		local splash = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.WATER_RIPPLE, 0, effect.Position, Vector.Zero, effect):ToEffect()
		splash.SpriteScale = Vector.One * 3
		for _, pickup in pairs(Isaac.FindInRadius(effect.Position, DelugeOrb.Radius, EntityPartition.PICKUP)) do
			if pickup:ToPickup() then
				pickup.GridCollisionClass = GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER
			end
		end
	end
	local swirl = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.WHIRLPOOL, 1, effect.Position, Vector.Zero, effect.Parent):ToEffect()
	swirl:FollowParent(effect)
	swirl.SpriteScale = Vector.One * DelugeOrb.SwirlScale
	swirl:SetColor(Color(1,1,1,DelugeOrb.SwirlAlpha), -1, 1, false, true)
end
MilkshakeVol1:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, DelugeOrb.onWaterfallDownUpdate, enums.Effects.DELUGE_LASER)

function DelugeOrb:onWaterfallUpUpdate(effect)
	--local effectData = effect:GetData()
	if not utility:GetData(effect, "DelugeOrb") then return end
	effect.ParentOffset = Vector(0, -32*effect.Parent.SpriteScale.Y)
	if effect.FrameCount == DelugeOrb.DelayBetweenLasers then
		local double = utility:GetData(effect, "DelugeOrb")
		local effectDown = Isaac.Spawn(EntityType.ENTITY_EFFECT, enums.Effects.DELUGE_LASER, 0, game:GetRoom():GetCenterPos(), Vector.Zero, effect.Parent):ToEffect()
		utility:SetData(effectDown, "DelugeOrb", double)
		effectDown.Parent = effect.Parent:ToPlayer()
		effectDown.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		effectDown.GridCollisionClass = EntityGridCollisionClass.GRIDCOLL_WALLS
		effectDown:SetTimeout(DelugeOrb.Timeout*double)
		effectDown:SetDamageSource(EntityType.ENTITY_PLAYER)
		effectDown:GetSprite():Play("Start")
		if not game:GetRoom():HasWater() then
			StopNextMusic = true
			utility:SetData(effectDown, "DelugeFlushed", true)
			local enemies = Isaac.FindInRadius(effect.Position, 5000, EntityPartition.ENEMY)
			for _, enemy in pairs(enemies) do
				if enemy:ToNPC() and enemy:IsVulnerableEnemy() and enemy:IsActiveEnemy() and not enemy:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
					enemy:AddEntityFlags(EntityFlag.FLAG_FRIENDLY)
					utility:SetData(enemy, "DelugeFlushed", true)
				end
			end
		end
	end
end
MilkshakeVol1:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, DelugeOrb.onWaterfallUpUpdate, EffectVariant.HUSH_LASER_UP)

if MMC then
	MMC.AddMusicCallback(
		MilkshakeVol1,
		function ()
			if StopNextMusic then
				return 0
			end
		end,
		Music.MUSIC_JINGLE_BOSS_OVER,
		Music.MUSIC_JINGLE_BOSS_OVER2,
		Music.MUSIC_JINGLE_BOSS_OVER3
	)
end

function DelugeOrb:OnDelugeOrbUse(_, player, flags) -- useFlag
	utility:SetData(player, "DelugeOrbUsed", true)
	local laserUp = Isaac.FindByType(EntityType.ENTITY_EFFECT, EffectVariant.HUSH_LASER_UP)
	local laserDown = Isaac.FindByType(EntityType.ENTITY_EFFECT, enums.Effects.DELUGE_LASER)
	if #laserDown > 0 and #laserUp > 0 then
		DelugeOrb.ExtraUse(laserUp, 2)
		DelugeOrb.ExtraUse(laserDown)
	else
		utility:SetBlindfold(player, true)
		player:AddNullCostume(enums.Costumes.DELUGE_ORB)
		local double = flags & enums.UseOrbFlags.DOUBLE_POWER > 0 and 2 or 1
		local effectUp = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.HUSH_LASER_UP, 0, player.Position, Vector.Zero, player):ToEffect()
		utility:SetData(effectUp, "DelugeOrb", double)
		effectUp.Parent = player
		effectUp:FollowParent(player)
		effectUp.ParentOffset = Vector(0, -32*player.SpriteScale.Y)
		effectUp:SetTimeout(2*DelugeOrb.Timeout*double)
		effectUp.DepthOffset = 999
		sfx:Play(enums.Sounds.WATER_FLOW, 0.75, 0, true, 1, 0)
	end
end
MilkshakeVol1:AddCallback(enums.Callbacks.ON_ORB_USE, DelugeOrb.OnDelugeOrbUse, enums.Orbs.WATER)
