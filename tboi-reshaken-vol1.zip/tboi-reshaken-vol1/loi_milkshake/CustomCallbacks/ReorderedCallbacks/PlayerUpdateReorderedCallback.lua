TSIL.__RegisterCustomCallback(
    TSIL.Enums.CustomCallback.POST_PLAYER_UPDATE_REORDERED,
    TSIL.Enums.CallbackReturnMode.NONE,
    TSIL.Enums.CallbackOptionalArgType.PLAYER_TYPE_VARIANT
)