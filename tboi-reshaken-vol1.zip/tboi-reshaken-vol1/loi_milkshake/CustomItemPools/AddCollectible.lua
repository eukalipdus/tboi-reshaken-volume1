



function TSIL.CustomItemPools.AddCollectibleToRegisteredPool(customItemPoolType, newItemPoolCollectible)
    local registeredItemPool = TSIL.__VERSION_PERSISTENT_DATA.CustomItemPools[customItemPoolType]

    if not registeredItemPool then
        error("There is no registered item pool with that id: " .. customItemPoolType)
    end

    local inItemPool = TSIL.Utils.Tables.Some(registeredItemPool, function (itemPoolCollectible)
        return itemPoolCollectible.Collectible == newItemPoolCollectible.Collectible
    end)

    if inItemPool then
        return
    end

    registeredItemPool[#registeredItemPool+1] = newItemPoolCollectible
end


