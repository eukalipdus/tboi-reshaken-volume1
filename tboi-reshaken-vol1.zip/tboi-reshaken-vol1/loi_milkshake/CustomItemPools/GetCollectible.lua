
function TSIL.CustomItemPools.GetCollectible(customItemPoolType, decrease, seedOrRNG, defaultItem)
    if decrease == nil then
        decrease = true
    end

    seedOrRNG = seedOrRNG or TSIL.RNG.GetRandomSeed()

    local rng

    if TSIL.IsaacAPIClass.IsRNG(seedOrRNG) then
        rng = seedOrRNG
    else
        rng = TSIL.RNG.NewRNG(seedOrRNG)
    end

    if defaultItem == nil then
        defaultItem = CollectibleType.COLLECTIBLE_NULL
    end

    local customItemPools = TSIL.SaveManager.GetPersistentVariable(
        TSIL.__MOD,
        "itemPools_CUSTOM_ITEM_POOLS"
    )
    local itemPoolCollectibles = customItemPools[customItemPoolType]

    if not itemPoolCollectibles then
        error("There is no registered item pool with that id: " .. customItemPoolType)
    end

    if #itemPoolCollectibles == 0 then
        local returnVal = TSIL.__TriggerCustomCallback(
            TSIL.Enums.CustomCallback.POST_GET_COLLECTIBLE_CUSTOM_ITEM_POOL,
            defaultItem,
            customItemPoolType,
            decrease,
            rng:GetSeed()
        )

        if returnVal then
            return returnVal
        end

        return defaultItem
    end

    local weigthedList = TSIL.Utils.Tables.Map(itemPoolCollectibles, function (_, itemPoolCollectible)
        return {
            chance = itemPoolCollectible.Weight,
            value = itemPoolCollectible.Collectible
        }
    end)
    local chosenCollectible = TSIL.Random.GetRandomElementFromWeightedList(rng, weigthedList)

    for index, itemPoolCollectible in ipairs(itemPoolCollectibles) do
        if itemPoolCollectible.Collectible == chosenCollectible and decrease then
            itemPoolCollectible.Weight = itemPoolCollectible.Weight - itemPoolCollectible.DecreaseBy

            if itemPoolCollectible.Weight < itemPoolCollectible.RemoveOn then
                table.remove(itemPoolCollectibles, index)
            end

            break
        end
    end

    local returnVal = TSIL.__TriggerCustomCallback(
        TSIL.Enums.CustomCallback.POST_GET_COLLECTIBLE_CUSTOM_ITEM_POOL,
        chosenCollectible,
        customItemPoolType,
        decrease,
        rng:GetSeed()
    )

    if returnVal then
        chosenCollectible = returnVal
    end

    return chosenCollectible
end


function TSIL.CustomItemPools.GetCollectibleEntriesInItemPool(customItemPoolType)
    local customItemPools = TSIL.SaveManager.GetPersistentVariable(
        TSIL.__MOD,
        "itemPools_CUSTOM_ITEM_POOLS"
    )
    local itemPoolCollectibles = customItemPools[customItemPoolType]

    if not itemPoolCollectibles then
        error("There is no registered item pool with that id: " .. customItemPoolType)
    end

    return TSIL.Utils.Tables.Copy(itemPoolCollectibles)
end