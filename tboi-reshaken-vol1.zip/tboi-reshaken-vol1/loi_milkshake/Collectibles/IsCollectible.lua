local function InitQuestionMarkSprite()
    local sprite = Sprite()
    sprite:Load("gfx/005.100_collectible.anm2", false)
    sprite:ReplaceSpritesheet(1, "gfx/items/collectibles/questionmark.png")
    sprite:LoadGraphics()

    return sprite
end

local questionMarkSprite = InitQuestionMarkSprite()








function TSIL.Collectibles.IsPassiveCollectible(collectibleType)
    local itemConfigItem = Isaac.GetItemConfig():GetCollectible(collectibleType)

    return itemConfigItem.Type == ItemType.ITEM_PASSIVE or itemConfigItem.Type == ItemType.ITEM_FAMILIAR
end