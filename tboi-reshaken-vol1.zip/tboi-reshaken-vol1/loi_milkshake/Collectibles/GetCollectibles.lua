function TSIL.Collectibles.GetCollectibles()
	local collectibles = {}

	local itemConfig = Isaac.GetItemConfig()
	local itemList = itemConfig:GetCollectibles()

	for id = 1, itemList.Size - 1, 1 do
		local item = itemConfig:GetCollectible(id)
		if item then
			table.insert(collectibles, item)
		end
	end

	return collectibles
end







