function TSIL.Dimensions.InDimension(dimension)
    return TSIL.Dimensions.GetDimension() == dimension
end