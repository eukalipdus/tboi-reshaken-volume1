TSIL.Enums.CustomReviveType = {
    SAME_ROOM = 0,

    PREVIOUS_ROOM = 1
}