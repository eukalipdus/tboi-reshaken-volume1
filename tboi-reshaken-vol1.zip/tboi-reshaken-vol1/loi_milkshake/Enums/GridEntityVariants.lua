TSIL.Enums.CrawlSpaceVariant = {
	NORMAL = 0,
	GREAT_GIDEON = 1,
	SECRET_SHOP = 2,
	PASSAGE_TO_BEGGINING_OF_FLOOR = 3,
	NULL = 4
}



TSIL.Enums.PoopGridEntityVariant = {
	NORMAL = 0,
	RED = 1,
	CORN = 2,
	GOLDEN = 3,
	RAINBOW = 4,
	BLACK = 5,
	WHITE = 6,
	GIGA_TOP_LEFT = 7,
	GIGA_TOP_RIGHT = 8,
	GIGA_BOTTOM_LEFT = 9,
	GIGA_BOTTOM_RIGHT = 10,
	CHARMING = 11
}






TSIL.Enums.StatueVariant = {
	DEVIL = 0,
	ANGEL = 1
}

