TSIL.Enums.SlotVariant = {
	SLOT_MACHINE = 1,
	BLOOD_DONATION_MACHINE = 2,
	FORTUNE_TELLING_MACHINE = 3,
	BEGGAR = 4,
	DEVIL_BEGGAR = 5,
	SHELL_GAME = 6,
	KEY_BEGGAR = 7,
	DONATION_MACHINE = 8,
	BOMB_BEGGAR = 9,
	RESTOCK_MACHINE = 10,
	GREED_DONATION_MACHINE = 11,
	DRESSING_TABLE = 12,
	BATTERY_BEGGAR = 13,
	TAINTED_UNLOCK = 14,
	HELL_GAME = 15,
	CRANE_GAME = 16,
	CONFESSIONAL = 17,
	ROTTEN_BEGGAR = 18
}


TSIL.Enums.KnifeVariant = {
    MOMS_KNIFE = 8,
    BONE_CLUB = 1,
    BONE_SCYTHE = 2,
    DONKEY_JAWBONE = 3,
    BAG_OF_CRAFTING = 4,
    SUMPTORIUM = 5,
    NOTCHED_AXE = 9,
    SPIRIT_SWORD = 10,
    TECH_SWORD = 11,
}











TSIL.Enums.GlobinVariant = {
  GLOBIN = 0,
  GAZING_GLOBIN = 1,
  DANK_GLOBIN = 2,
  CURSED_GLOBIN = 3,
}




































































TSIL.Enums.PoopEntityVariant = {
  NORMAL = 0,
  GOLDEN = 1,
  STONE = 11,
  CORNY = 12,
  BURNING = 13,
  STINKY = 14,
  BLACK = 15,
  HOLY = 16,
}



























































