function TSIL.Charge.GetMaxCharges(player, activeSlot)
    if not activeSlot then activeSlot = ActiveSlot.SLOT_PRIMARY end

    local previousCharge = TSIL.Charge.GetTotalCharge(player, activeSlot)
    player:SetActiveCharge(math.floor(math.maxinteger/100), activeSlot)
    local currentCharge = player:GetActiveCharge(activeSlot)
    player:SetActiveCharge(previousCharge, activeSlot)

    return currentCharge
end
