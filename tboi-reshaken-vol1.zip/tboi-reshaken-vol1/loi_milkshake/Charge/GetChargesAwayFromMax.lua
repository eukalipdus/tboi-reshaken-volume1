function TSIL.Charge.GetChargesAwayFromMax(player, activeSlot)
    local totalCharge = TSIL.Charge.GetTotalCharge(player, activeSlot)
    local hasBattery = player:HasCollectible(CollectibleType.COLLECTIBLE_BATTERY)
    local maxCharges = TSIL.Charge.GetMaxCharges(player, activeSlot)

    local effectiveMaxCharges

    if hasBattery then
        effectiveMaxCharges = maxCharges * 2
    else
        effectiveMaxCharges = maxCharges
    end

    return effectiveMaxCharges - totalCharge;
end