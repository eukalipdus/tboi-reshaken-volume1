



function TSIL.PickupSpecific.SpawnCard(cardType, position, velocity, spawner, seedOrRNG)
    return TSIL.EntitySpecific.SpawnPickup(
        PickupVariant.PICKUP_TAROTCARD,
        cardType,
        position,
        velocity,
        spawner,
        seedOrRNG
    )
end


function TSIL.PickupSpecific.SpawnCoin(coinSubtype, position, velocity, spawner, seedOrRNG)
    return TSIL.EntitySpecific.SpawnPickup(
        PickupVariant.PICKUP_COIN,
        coinSubtype,
        position,
        velocity,
        spawner,
        seedOrRNG
    )
end


function TSIL.PickupSpecific.SpawnHeart(heartSubtype, position, velocity, spawner, seedOrRNG)
    return TSIL.EntitySpecific.SpawnPickup(
        PickupVariant.PICKUP_HEART,
        heartSubtype,
        position,
        velocity,
        spawner,
        seedOrRNG
    )
end


function TSIL.PickupSpecific.SpawnKey(keySubtype, position, velocity, spawner, seedOrRNG)
    return TSIL.EntitySpecific.SpawnPickup(
        PickupVariant.PICKUP_KEY,
        keySubtype,
        position,
        velocity,
        spawner,
        seedOrRNG
    )
end


function TSIL.PickupSpecific.SpawnPill(pillColor, position, velocity, spawner, seedOrRNG)
    return TSIL.EntitySpecific.SpawnPickup(
        PickupVariant.PICKUP_PILL,
        pillColor,
        position,
        velocity,
        spawner,
        seedOrRNG
    )
end



