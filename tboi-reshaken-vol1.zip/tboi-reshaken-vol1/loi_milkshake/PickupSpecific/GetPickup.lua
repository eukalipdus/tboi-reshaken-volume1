







function TSIL.PickupSpecific.GetCollectibles(collectibleType)
    return TSIL.EntitySpecific.GetPickups(PickupVariant.PICKUP_COLLECTIBLE, collectibleType)
end









