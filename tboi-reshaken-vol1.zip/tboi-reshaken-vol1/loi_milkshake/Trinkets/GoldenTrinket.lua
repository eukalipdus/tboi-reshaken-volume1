function TSIL.Trinkets.IsGoldenTrinket(trinketType)
    return TSIL.Utils.Flags.HasFlags(trinketType, TrinketType.TRINKET_GOLDEN_FLAG)
end


function TSIL.Trinkets.GetGoldenTrinketType(trinketType)
    return TSIL.Utils.Flags.AddFlags(trinketType, TrinketType.TRINKET_GOLDEN_FLAG)
end

