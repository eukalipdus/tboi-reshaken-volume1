local MOVE_ACTIONS = {
    ButtonAction.ACTION_LEFT,
    ButtonAction.ACTION_UP,
    ButtonAction.ACTION_RIGHT,
    ButtonAction.ACTION_DOWN
}

local SHOOT_ACTIONS = {
    ButtonAction.ACTION_SHOOTLEFT,
    ButtonAction.ACTION_SHOOTUP,
    ButtonAction.ACTION_SHOOTRIGHT,
    ButtonAction.ACTION_SHOOTDOWN
}




function TSIL.Input.GetShootActions()
    return TSIL.Utils.Tables.Copy(SHOOT_ACTIONS)
end