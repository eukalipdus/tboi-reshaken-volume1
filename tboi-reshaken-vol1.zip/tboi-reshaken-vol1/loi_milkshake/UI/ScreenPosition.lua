

function TSIL.UI.GetScreenBottomRightPosition()
	local screenWidth = Isaac.GetScreenWidth()
	local screenHeight = Isaac.GetScreenHeight()

	return Vector(screenWidth, screenHeight)
end

function TSIL.UI.GetScreenCenterPosition()
	local bottomRight = TSIL.UI.GetScreenBottomRightPosition()
	return bottomRight / 2
end



