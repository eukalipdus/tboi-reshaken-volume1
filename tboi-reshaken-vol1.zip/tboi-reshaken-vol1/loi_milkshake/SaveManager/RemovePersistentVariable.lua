
function TSIL.SaveManager.RemovePersistentVariable(mod, variableName)
	local PersistentData = TSIL.__VERSION_PERSISTENT_DATA.PersistentData

	local tables = TSIL.Utils.Tables

	local modPersistentData = PersistentData[mod.Name]

	if modPersistentData == nil then
		return
	end

	local modVariables = modPersistentData.variables

	modVariables[variableName] = nil
end