

function TSIL.Players.TemporarilyRemoveTrinket(player, trinketType)
    if not player:HasTrinket(trinketType) then
        return nil
    end

    local trinketType1 = player:GetTrinket(0)
    local trinketType2 = player:GetTrinket(1)

    local numTrinkets = 0
    while player:HasTrinket(trinketType) do
        player:TryRemoveTrinket(trinketType)
        numTrinkets = numTrinkets + 1
    end

    local numSmeltedTrinkets = numTrinkets
    local trinketWasInSlot1 = trinketType1 == trinketType or
        trinketType1 == TSIL.Trinkets.GetGoldenTrinketType(trinketType)
    if trinketWasInSlot1 then
        numSmeltedTrinkets = numSmeltedTrinkets - 1
    end

    local trinketWasInSlot2 = trinketType2 == trinketType or
        trinketType2 == TSIL.Trinkets.GetGoldenTrinketType(trinketType)
    if trinketWasInSlot2 then
        numSmeltedTrinkets = numSmeltedTrinkets - 1
    end

    return {
        TrinketTypeRemoved = trinketType,
        TrinketType1 = trinketType1,
        TrinketType2 = trinketType2,
        NumSmeltedTrinkets = numSmeltedTrinkets,
    }
end




function TSIL.Players.GiveTrinketsBack(player, trinketSituation)
    if trinketSituation == nil then
        return
    end

    local trinketType1 = player:GetTrinket(0)
    local trinketType2 = player:GetTrinket(1)

    if trinketType1 ~= TrinketType.TRINKET_NULL then
        player:TryRemoveTrinket(trinketType1)
    end

    if trinketType2 ~= TrinketType.TRINKET_NULL then
        player:TryRemoveTrinket(trinketType2)
    end

    for _ = 1, trinketSituation.NumSmeltedTrinkets, 1 do
        TSIL.Players.AddSmeltedTrinket(player, trinketSituation.TrinketTypeRemoved)
    end

    if trinketSituation.TrinketType1 ~= TrinketType.TRINKET_NULL then
        player:AddTrinket(trinketSituation.TrinketType1, false)
    end
    if trinketSituation.TrinketType2 ~= TrinketType.TRINKET_NULL then
        player:AddTrinket(trinketSituation.TrinketType2, false)
    end
end
