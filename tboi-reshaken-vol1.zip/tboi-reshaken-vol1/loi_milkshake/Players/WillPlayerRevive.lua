function TSIL.Players.IsDamageToPlayerFatal(player, amount, source, lastDamageGameFrame)
    local gameFrameCount = Game():GetFrameCount();
    local character = player:GetPlayerType();
    local effects = player:GetEffects();
    local isBerserk = effects:HasCollectibleEffect(CollectibleType.COLLECTIBLE_BERSERK);

    if character == PlayerType.PLAYER_JACOB_B and
    source.Type == EntityType.ENTITY_DARK_ESAU then
        return false
    end
  
    if isBerserk then
        return false
    end

    local TAINTED_SAMSON_BERSERK_CHARGE_FROM_TAKING_DAMAGE = 10000
    local berserkChargeAfterHit = player.SamsonBerserkCharge + TAINTED_SAMSON_BERSERK_CHARGE_FROM_TAKING_DAMAGE

    local MAX_TAINTED_SAMSON_BERSERK_CHARGE = 100000
    if character == PlayerType.SAMSON_B and
    berserkChargeAfterHit >= MAX_TAINTED_SAMSON_BERSERK_CHARGE then
        return false
    end

    if TSIL.Players.WillReviveFromSpiritShackles(player) then
        return false
    end

    if character == PlayerType.PLAYER_JACOB2_B then
        return true
    end

    local hasLostCurse = effects:HasNullEffect(NullItemID.ID_LOST_CURSE)
    if hasLostCurse then
        return true
    end

    local playerNumAllHearts = TSIL.Players.GetPlayerNumHitsRemaining(player)
    if amount < playerNumAllHearts then
        return false
    end

    if TSIL.Players.WillReviveFromHeartbreak(player) then
        return false
    end

    if player:HasCollectible(CollectibleType.COLLECTIBLE_BROKEN_GLASS_CANNON) and
    gameFrameCount == lastDamageGameFrame then
        return false
    end

    local hearts = player:GetHearts();
    local eternalHearts = player:GetEternalHearts();
    local soulHearts = player:GetSoulHearts();
    local boneHearts = player:GetBoneHearts();
    if (hearts > 0 and soulHearts > 0) or
      (hearts > 0 and boneHearts > 0) or
      (soulHearts > 0 and boneHearts > 0) or
      (soulHearts > 0 and eternalHearts > 0) or
      boneHearts >= 2 -- Two bone hearts and nothing else should not result in a death
    then
        return false;
    end
  
    return true
end


function TSIL.Players.WillMysteriousPaperRevive(player)
    local gameFrameCount = Game():GetFrameCount()
    local sprite = player:GetSprite()

    local character = player:GetPlayerType()
    local animation = TSIL.Players.GetCharacterDeathAnimationName(character)
    local deathAnimationFrames = TSIL.Sprites.GetLastFrameOfAnimation(sprite, animation)
    local frameOfDeath = gameFrameCount + deathAnimationFrames + 1

    return frameOfDeath % 4 == 3;
end


function TSIL.Players.WillPlayerRevive(player)
    local trinketSituation = TSIL.Players.TemporarilyRemoveTrinket(player, TrinketType.TRINKET_MYSTERIOUS_PAPER)

    local willRevive = player:WillPlayerRevive() or
      (trinketSituation ~= nil and TSIL.Players.WillMysteriousPaperRevive(player))

    TSIL.Players.GiveTrinketsBack(player, trinketSituation)

    return willRevive
end


function TSIL.Players.WillReviveFromHeartbreak(player)
    if not player:HasCollectible(CollectibleType.COLLECTIBLE_HEARTBREAK) then
     	return false
	end

    local maxHeartContainers = TSIL.Players.GetPlayerMaxHeartContainers(player)
    local numBrokenHeartsThatWillBeAdded = 2
	if TSIL.Players.IsKeeper(player) then
		numBrokenHeartsThatWillBeAdded = 1
	end
    local brokenHearts = player:GetBrokenHearts()
    local numBrokenHeartsAfterRevival = numBrokenHeartsThatWillBeAdded + brokenHearts

    return maxHeartContainers > numBrokenHeartsAfterRevival;
end


function TSIL.Players.WillReviveFromSpiritShackles(player)
    if not player:HasCollectible(CollectibleType.COLLECTIBLE_SPIRIT_SHACKLES) then
     	return false
	end

	local effects = player:GetEffects()

    local spiritShacklesEnabled = not effects:HasNullEffect(NullItemID.ID_SPIRIT_SHACKLES_DISABLED)
    local playerInSoulForm = effects:HasNullEffect(NullItemID.ID_SPIRIT_SHACKLES_SOUL)

    return spiritShacklesEnabled and not playerInSoulForm
end