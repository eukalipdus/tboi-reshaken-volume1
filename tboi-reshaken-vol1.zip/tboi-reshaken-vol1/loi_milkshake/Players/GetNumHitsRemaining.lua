function TSIL.Players.GetPlayerNumHitsRemaining(player)
    local hearts = player:GetHearts()
    local soulHearts = player:GetSoulHearts();
    local boneHearts = player:GetBoneHearts();
    local eternalHearts = player:GetEternalHearts();
    local rottenHearts = player:GetRottenHearts();

    return hearts + soulHearts + boneHearts + eternalHearts - rottenHearts;
end