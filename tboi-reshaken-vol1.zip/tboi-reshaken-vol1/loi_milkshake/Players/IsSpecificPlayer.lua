function TSIL.Players.IsKeeper(player)
    return player:GetPlayerType() == PlayerType.PLAYER_KEEPER or
    player:GetPlayerType() == PlayerType.PLAYER_KEEPER_B
end




function TSIL.Players.IsTheLost(player)
    return player:GetPlayerType() == PlayerType.PLAYER_THELOST or
    player:GetPlayerType() == PlayerType.PLAYER_THELOST_B
end




function TSIL.Players.IsJacobOrEsau(player)
    return player:GetPlayerType() == PlayerType.PLAYER_JACOB or
    player:GetPlayerType() == PlayerType.PLAYER_ESAU
end