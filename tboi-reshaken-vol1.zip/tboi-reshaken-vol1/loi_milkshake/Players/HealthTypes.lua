function TSIL.Players.GetHearts(player)
    local rottenHearts = player:GetRottenHearts()
    local hearts = player:GetHearts()

    return hearts - rottenHearts * 2;
end

function TSIL.Players.GetSoulHearts(player)
    local soulHearts = player:GetSoulHearts();
    local blackHearts = TSIL.Players.GetBlackHeartsNum(player);

  return soulHearts - blackHearts
end


function TSIL.Players.GetBlackHeartsNum(player)
    local blackHeartsBitmask = player:GetBlackHearts();
    local blackHeartBits = TSIL.Utils.Flags.CountBits(blackHeartsBitmask);

    return blackHeartBits * 2;
end


function TSIL.Players.GetPlayerHealthType(player, healthType)
    local HealthType = TSIL.Enums.HealthType
    if healthType == HealthType.RED then
        return TSIL.Players.GetHearts(player)
    elseif healthType == HealthType.SOUL then
        return TSIL.Players.GetSoulHearts(player)
    elseif healthType == HealthType.ETERNAL then
        return player:GetEternalHearts()
    elseif healthType == HealthType.BLACK then
        return TSIL.Players.GetBlackHeartsNum(player)
    elseif healthType == HealthType.GOLDEN then
        return player:GetGoldenHearts()
    elseif healthType == HealthType.BONE then
        return player:GetBoneHearts()
    elseif healthType == HealthType.ROTTEN then
        return player:GetRottenHearts()
    elseif healthType == HealthType.BROKEN then
        return player:GetBrokenHearts()
    elseif healthType == HealthType.MAX_HEARTS then
        return player:GetMaxHearts()
    end
end