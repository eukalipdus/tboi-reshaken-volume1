function TSIL.Players.IsChildPlayer(player)
    return player.Parent ~= nil
end