

local function OnTSILLoaded()
    TSIL.SaveManager.AddPersistentVariable(
		TSIL.__MOD,
		"playerInventories_PLAYER_INVENTORY",
		{},
		TSIL.Enums.VariablePersistenceMode.RESET_RUN
	)
end
TSIL.__AddInternalCallback(
	"PLAYER_INVENTORY_TSIL_LOADED",
	TSIL.Enums.CustomCallback.POST_TSIL_LOAD,
	OnTSILLoaded
)


local function GetPlayerInventory(player)
	local playerIndex = TSIL.Players.GetPlayerIndex(player)
	local playerInventories = TSIL.SaveManager.GetPersistentVariable(
		TSIL.__MOD,
		"playerInventories_PLAYER_INVENTORY"
	)

	local inventory = playerInventories[playerIndex]
	if not inventory then
		inventory = {}
		playerInventories[playerIndex] = inventory
	end

	return inventory
end


local function OnCollectibleAdded(_, player, item)
	if not TSIL.Collectibles.IsPassiveCollectible(item) then return end

	local inventory = GetPlayerInventory(player)

	inventory[#inventory+1] = {
		Id = item,
		Type = TSIL.Enums.InventoryType.COLLECTIBLE
	}
end
TSIL.__AddInternalCallback(
	"PLAYER_INVENTORY_ON_COLLECTIBLE_ADDED",
	TSIL.Enums.CustomCallback.POST_PLAYER_COLLECTIBLE_ADDED,
	OnCollectibleAdded
)


local function OnCollectibleRemoved(_, player, item)
	local inventory = GetPlayerInventory(player)

	for index, inventoryObject in ipairs(inventory) do
		if inventoryObject.Type == TSIL.Enums.InventoryType.COLLECTIBLE
		and inventoryObject.Id == item then
			table.remove(inventory, index)
			break
		end
	end
end
TSIL.__AddInternalCallback(
	"PLAYER_INVENTORY_ON_COLLECTIBLE_REMOVED",
	TSIL.Enums.CustomCallback.POST_PLAYER_COLLECTIBLE_REMOVED,
	OnCollectibleRemoved
)


local function OnGulpedTrinketAdded(_, player, trinket)
	local inventory = GetPlayerInventory(player)

	inventory[#inventory+1] = {
		Id = trinket,
		Type = TSIL.Enums.InventoryType.TRINKET
	}
end
TSIL.__AddInternalCallback(
	"PLAYER_INVENTORY_ON_GULPED_TRINKET_ADDED",
	TSIL.Enums.CustomCallback.POST_PLAYER_GULPED_TRINKET_ADDED,
	OnGulpedTrinketAdded
)


local function OnGulpedTrinketRemoved(_, player, trinket)
	local inventory = GetPlayerInventory(player)

	for index, inventoryObject in ipairs(inventory) do
		if inventoryObject.Type == TSIL.Enums.InventoryType.TRINKET
		and inventoryObject.Id == trinket then
			table.remove(inventory, index)
			break
		end
	end
end
TSIL.__AddInternalCallback(
	"PLAYER_INVENTORY_ON_GULPED_TRINKET_REMOVED",
	TSIL.Enums.CustomCallback.POST_PLAYER_GULPED_TRINKET_REMOVED,
	OnGulpedTrinketRemoved
)


function TSIL.Players.GetPlayerInventory(player, inventoryTypeFilter)
	local playerIndex = TSIL.Players.GetPlayerIndex(player)

	local TablesUtils = TSIL.Utils.Tables

	local playerInventories = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "playerInventories_PLAYER_INVENTORY")

	if playerInventories[playerIndex] == nil then
		return {}
	end

	local chosenInventory = playerInventories[playerIndex]

	if inventoryTypeFilter then
		local filteredInventory = TablesUtils.Filter(chosenInventory, function(_, inventoryItem)
			return inventoryItem.Type == inventoryTypeFilter
		end)

		return filteredInventory
	else
		return TablesUtils.Copy(chosenInventory)
	end
end