function TSIL.Players.GetCharacterMaxHeartContainers(character)
    if character == PlayerType.PLAYER_KEEPER then
        return 3
    end

    if character == PlayerType.PLAYER_THEFORGOTTEN then
        return 6
    end

    if character == PlayerType.PLAYER_THESOUL then
        return 6
    end

    if character == PlayerType.PLAYER_KEEPER_B then
        return 2
    end

    return 12
end


function TSIL.Players.GetPlayerMaxHeartContainers(player)
    local character = player:GetPlayerType()
    local characterMaxHeartContainers = TSIL.Players.GetCharacterMaxHeartContainers(character)

    if character == PlayerType.MAGDALENE and player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
        local extraMaxHeartContainersFromBirthright = 6
        return characterMaxHeartContainers + extraMaxHeartContainersFromBirthright
    end

    if TSIL.Players.IsKeeper(player) then
        local numMothersKisses = player:GetTrinketMultiplier(TrinketType.MOTHERS_KISS)
        local hasGreedsGullet = player:HasCollectible(CollectibleType.GREEDS_GULLET)
        local coins = player:GetNumCoins()
        local greedsGulletCoinContainers = 0

        if hasGreedsGullet then
            greedsGulletCoinContainers = math.floor(coins / 25)
        end

        return characterMaxHeartContainers +
            numMothersKisses +
            greedsGulletCoinContainers
    end

    return characterMaxHeartContainers
end
