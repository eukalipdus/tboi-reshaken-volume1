


local function OnTSILLoad()
    local AddVariable = TSIL.SaveManager.AddPersistentVariable

    AddVariable(TSIL.__MOD, "pickupCounter_PICKUP_INDEX", 0, TSIL.Enums.VariablePersistenceMode.RESET_RUN)
    AddVariable(TSIL.__MOD, "pickupDataTreasureRooms_PICKUP_INDEX", {}, TSIL.Enums.VariablePersistenceMode.RESET_RUN)
    AddVariable(TSIL.__MOD, "pickupDataBossRooms_PICKUP_INDEX", {}, TSIL.Enums.VariablePersistenceMode.RESET_RUN)

    AddVariable(TSIL.__MOD, "pickupData_PICKUP_INDEX", {}, TSIL.Enums.VariablePersistenceMode.RESET_LEVEL)

    AddVariable(TSIL.__MOD, "pickupIndexes_PICKUP_INDEX", {}, TSIL.Enums.VariablePersistenceMode.RESET_ROOM)
end

TSIL.__AddInternalCallback(
    "PICKUP_INDEX_ON_TSIL_LOAD",
    TSIL.Enums.CustomCallback.POST_TSIL_LOAD,
    OnTSILLoad
)


local function GetStoredPickupIndex(pickup, pickupDescriptions)
    for pickupIndex, pickupDescription in pairs(pickupDescriptions) do
        if TSIL.Vector.VectorEquals(pickup.Position, pickupDescription.Position) and
            pickup.InitSeed == pickupDescription.InitSeed then
            return pickupIndex
        end
    end
end

local function GetPostAscentPickupIndex(pickup)
    if not TSIL.Stage.OnAscent() then
        return nil
    end

    local room = Game():GetRoom();
    local roomType = room:GetType();

    if roomType == RoomType.ROOM_TREASURE then
        local treasurePickups = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupDataTreasureRooms_PICKUP_INDEX")
        return GetStoredPickupIndex(pickup, treasurePickups)
    elseif roomType == RoomType.ROOM_BOSS then
        local bossPickups = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupDataBossRooms_PICKUP_INDEX")
        return GetStoredPickupIndex(pickup, bossPickups)
    end
end

local function TrackDespawningPickupMetadata(entity, pickupIndex)
    local previousRoomDescription = TSIL.Rooms.GetLatestRoomDescription()
    if previousRoomDescription == nil then
        return
    end

    local previousRoomListIndex = previousRoomDescription.RoomListIndex
    local pickupData = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupData_PICKUP_INDEX")
    local pickupDescriptions = pickupData[tostring(previousRoomListIndex)]

    if pickupDescriptions == nil then
        pickupDescriptions = {}
        pickupData[tostring(previousRoomListIndex)] = pickupDescriptions
    end

    local pickupDescription = {
        Position = entity.Position,
        InitSeed = entity.InitSeed,
    }
    pickupDescriptions[tostring(pickupIndex)] = pickupDescription

    if TSIL.Stage.OnAscent() then
        return
    end

    local room = Game():GetRoom();
    local roomType = room:GetType();

    if roomType == RoomType.ROOM_TREASURE then
        local treasurePickups = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupDataTreasureRooms_PICKUP_INDEX")
        treasurePickups[tostring(pickupIndex)] = pickupDescription
    elseif roomType == RoomType.BOSS then
        local bossPickups = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupDataBossRooms_PICKUP_INDEX")
        bossPickups[tostring(pickupIndex)] = pickupDescription
    end
end

local function CheckDespawningFromPlayerLeavingRoom(entity)
    local ptrHash = GetPtrHash(entity);
    local pickupIndexes = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupIndexes_PICKUP_INDEX")
    local pickupIndex = pickupIndexes[tostring(ptrHash)]

    if pickupIndex == nil then
        return
    end

    if not TSIL.Rooms.IsLeavingRoom() then
        return
    end

    TrackDespawningPickupMetadata(entity, pickupIndex);
end

local function GetPickupIndexFromPreviousData(pickup)
    local level = Game():GetLevel()
    local roomDescriptor = level:GetCurrentRoomDesc()
    local roomListIndex = roomDescriptor.ListIndex

    local pickupData = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupData_PICKUP_INDEX")
    local pickupDescriptions = pickupData[tostring(roomListIndex)]

    if pickupDescriptions == nil then
        pickupDescriptions = {}
        pickupData[tostring(roomListIndex)] = pickupDescriptions
    end

    local pickupIndex = GetStoredPickupIndex(pickup, pickupDescriptions)
    if pickupIndex == nil then
        pickupIndex = GetPostAscentPickupIndex(pickup)
    end

    return pickupIndex
end

local function SetPickupIndex(pickup)
    local ptrHash = GetPtrHash(pickup)

    local pickupIndexes = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupIndexes_PICKUP_INDEX")

    if pickupIndexes[tostring(ptrHash)] ~= nil then
        return
    end

    local pickupIndexFromLevelData = GetPickupIndexFromPreviousData(pickup)
    local room = Game():GetRoom()
    local isFirstVisit = room:IsFirstVisit()
    local roomFrameCount = room:GetFrameCount()
    if pickupIndexFromLevelData ~= nil and
    not isFirstVisit and
    roomFrameCount <= 0 then
        pickupIndexes[tostring(ptrHash)] = pickupIndexFromLevelData
        return
    end

    local pickupCounter = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupCounter_PICKUP_INDEX")
    pickupCounter = pickupCounter + 1
    TSIL.SaveManager.SetPersistentVariable(TSIL.__MOD, "pickupCounter_PICKUP_INDEX", pickupCounter)
    pickupIndexes[tostring(ptrHash)] = pickupCounter
end


local function PostPickupInit(_, pickup)
    SetPickupIndex(pickup)
end
TSIL.__AddInternalCallback(
    "PICKUP_INDEX_POST_PICKUP_INDEX",
    ModCallbacks.MC_POST_PICKUP_INIT,
    PostPickupInit
)


local function PostPickupRemove(_, pickup)
    CheckDespawningFromPlayerLeavingRoom(pickup)
end
TSIL.__AddInternalCallback(
    "PICKUP_INDEX_POST_ENTITY_REMOVED",
    ModCallbacks.MC_POST_ENTITY_REMOVE,
    PostPickupRemove,
    CallbackPriority.DEFAULT
)


function TSIL.Pickups.GetPickupIndex(pickup)
    local ptrHash = GetPtrHash(pickup)
    local pickupIndexes = TSIL.SaveManager.GetPersistentVariable(TSIL.__MOD, "pickupIndexes_PICKUP_INDEX")

    local pickupIndexInitial = pickupIndexes[tostring(ptrHash)]
    if pickupIndexInitial ~= nil then
        return pickupIndexInitial
    end

    SetPickupIndex(pickup)
    local pickupIndex = pickupIndexes[tostring(ptrHash)]
    if pickupIndex ~= nil then
        return pickupIndex
    end

    error("Failed to generate a new pickup index for pickup")
end