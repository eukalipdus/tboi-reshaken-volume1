
function TSIL.ShockWaves.CreateShockwave(source, position, customShockwaveParams)
    local room = Game():GetRoom()
    local gridIndex = room:GetClampedGridIndex(position)
    local gridEntity = room:GetGridEntity(gridIndex)

    local isOutside = gridIndex < 0 or gridIndex > room:GetGridSize()
    local isInForbiddenGrid = gridEntity and (
        gridEntity:GetType() == GridEntityType.GRID_WALL or
        gridEntity:GetType() == GridEntityType.GRID_DOOR or
        gridEntity:GetType() == GridEntityType.GRID_ROCKB or
        gridEntity:GetType() == GridEntityType.GRID_PILLAR)
    local cantDestroyRocks = not customShockwaveParams.DestroyGrid and room:GetGridCollision(gridIndex) ~= GridCollisionClass.COLLISION_NONE
    local cantGoOverPits = not customShockwaveParams.GoOverPits and gridEntity and gridEntity:GetType() == GridEntityType.GRID_PIT

    if isOutside or isInForbiddenGrid or cantDestroyRocks or cantGoOverPits then
        return
    end

    local shockwave = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCK_EXPLOSION, 0, position, Vector.Zero, source)
    shockwave.Size = shockwave.Size * customShockwaveParams.Size
    shockwave.Parent = source
    local sprite = shockwave:GetSprite()
    sprite.Scale = Vector(customShockwaveParams.Size, customShockwaveParams.Size)
    sprite.Color = customShockwaveParams.Color
    sprite:ReplaceSpritesheet(0, customShockwaveParams.SpriteSheet)
    sprite:LoadGraphics()

    if customShockwaveParams.SoundMode ~= TSIL.Enums.ShockwaveSoundMode.NO_SOUND then
        SFXManager():Play(SoundEffect.SOUND_ROCK_CRUMBLE, 0.5, 2, false, 1)
    end

    local saveManager = TSIL.SaveManager

    local customShockwaves = saveManager.GetPersistentVariable(TSIL.__MOD, "TSIL_CUSTOM_SHOCKWAVES")

    if not customShockwaves then
        saveManager.AddPersistentVariable(TSIL.__MOD, "TSIL_CUSTOM_SHOCKWAVES", {}, TSIL.Enums.VariablePersistenceMode.REMOVE_ROOM)
        customShockwaves = saveManager.GetPersistentVariable(TSIL.__MOD, "TSIL_CUSTOM_SHOCKWAVES")
    end

    customShockwaves[GetPtrHash(shockwave)] = {
        CustomShockwaveParams = customShockwaveParams,
        CurrentDuration = customShockwaveParams.Duration,
        HitEntities = {}
    }

    return shockwave
end


function TSIL.ShockWaves.CreateShockwaveRing(source, center, radius, customShockwaveParams, direction, angleWidth, spacing, numRings, ringSpacing, ringDelay)
    local shockwaves = {}

    if direction == nil then direction = Vector(0, -1) end
    direction:Normalized()
    if angleWidth == nil then angleWidth = 360 end
    angleWidth = math.min(angleWidth, 360)
    if spacing == nil then spacing = 35 * customShockwaveParams.Size end
    if numRings == nil then numRings = 1 end
    numRings = math.max(1, numRings)
    if ringSpacing == nil then ringSpacing = spacing end
    if ringDelay == nil then ringDelay = 5 end

    local totalPerimeter = math.pi * 2 * radius
    local widthPerimeter = angleWidth * totalPerimeter / 360

    local numShockwaves = math.max(1, math.floor(widthPerimeter / spacing + 0.5))

    local angleOffset = angleWidth/numShockwaves
    local currentDirection = direction:Rotated(-angleWidth/2)

    local room = Game():GetRoom()

    for _ = 0, numShockwaves, 1 do
        local spawningOffset = currentDirection * radius

        local mode = 0
        if customShockwaveParams.GoOverPits then
            mode = 3
        end

        if room:CheckLine(center, center + spawningOffset, mode, 1000, false, customShockwaveParams.DestroyGrid) then
            local shockwave = TSIL.ShockWaves.CreateShockwave(source, center + spawningOffset, customShockwaveParams)

            if shockwave then
                shockwaves[#shockwaves+1] = shockwave
            end
        end
        currentDirection = currentDirection:Rotated(angleOffset)
    end

    numRings = numRings - 1

    if numRings > 0 and #shockwaves > 0 then
        TSIL.Utils.Functions.RunInFrames(TSIL.ShockWaves.CreateShockwaveRing, ringDelay,
            source,
            center,
            radius + ringSpacing,
            customShockwaveParams,
            direction,
            angleWidth,
            spacing,
            numRings
        )
    end

    return shockwaves
end



