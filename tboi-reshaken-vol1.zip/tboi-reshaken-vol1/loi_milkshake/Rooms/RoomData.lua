



function TSIL.Rooms.GetRoomDescriptor(roomGridIndex)
	local level = Game():GetLevel()

	if roomGridIndex == nil then
		roomGridIndex = level:GetCurrentRoomIndex()
	end

	return level:GetRoomByIdx(roomGridIndex);
end


function TSIL.Rooms.GetRoomData(roomGridIndex)
	local roomDescriptor = TSIL.Rooms.GetRoomDescriptor(roomGridIndex);
	return roomDescriptor.Data
end


function TSIL.Rooms.GetRoomStageID(roomGridIndex)
	local roomData = TSIL.Rooms.GetRoomData(roomGridIndex)

	if roomData == nil then
		return -1
	end

	return roomData.StageID
end


function TSIL.Rooms.GetRoomSubType(roomGridIndex)
	local roomData = TSIL.Rooms.GetRoomData(roomGridIndex)

	if roomData == nil then
		return -1
	end

	return roomData.Subtype
end