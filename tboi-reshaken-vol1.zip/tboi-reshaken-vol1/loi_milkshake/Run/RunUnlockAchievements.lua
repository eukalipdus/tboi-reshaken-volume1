function TSIL.Run.CanRunUnlockAchievements()
    local greedDonation = TSIL.EntitySpecific.SpawnSlot(
        TSIL.Enums.SlotVariant.GREED_DONATION_MACHINE,
        0,
        Vector.Zero
    )

    local canUnlockAchievements = greedDonation:Exists()
    greedDonation:Remove()

    return canUnlockAchievements
end