

function TSIL.Utils.Easings.EaseOutSine(x)
	return math.sin((x * math.pi) / 2);
end








function TSIL.Utils.Easings.EaseInOutQuad(x)
	if x < 0.5 then
		return 2 * x * x
	else
		return 1 - (-2 * x + 2)^2 / 2
	end
end




























function TSIL.Utils.Easings.EaseOutCirc(x)
	return math.sqrt(1 - (x - 1)^2)
end



















