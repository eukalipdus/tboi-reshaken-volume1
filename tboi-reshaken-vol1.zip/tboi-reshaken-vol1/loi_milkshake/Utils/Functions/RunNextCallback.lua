function TSIL.Utils.Functions.RunNextCallback(mod, callback, funct, optionalParam)
    local callbackFunct
    callbackFunct = function (...)
        mod:RemoveCallback(callback, callbackFunct)
        return funct(...)
    end

    mod:AddCallback(
        callback,
        callbackFunct,
        optionalParam
    )
end