function TSIL.Utils.String.Split(s, separator)
    local result = {}
    for substring in string.gmatch(s, "([^" .. separator .. "]+)") do
        table.insert(result, substring)
    end

    return result
end