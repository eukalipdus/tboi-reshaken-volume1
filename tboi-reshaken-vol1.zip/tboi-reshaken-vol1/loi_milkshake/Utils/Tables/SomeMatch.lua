function TSIL.Utils.Tables.Some(tbl, predicate)
	for k, v in pairs(tbl) do
		if predicate(v, k, tbl) then
			return true
		end
	end

	return false
end
