function TSIL.Utils.Tables.Map(list, funct)
    local mapped = {}

    for key, value in pairs(list) do
        mapped[key] = funct(key, value)
    end

    return mapped
end