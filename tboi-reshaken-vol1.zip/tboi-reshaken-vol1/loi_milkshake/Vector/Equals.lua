function TSIL.Vector.VectorEquals(v1, v2)
    return v1.X == v2.X and v1.Y == v1.Y
end