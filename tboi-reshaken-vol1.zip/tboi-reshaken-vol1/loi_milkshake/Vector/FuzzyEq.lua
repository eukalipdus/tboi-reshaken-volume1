function TSIL.Vector.VectorFuzzyEquals(v1, v2, epsilon)
    epsilon = epsilon or 1e-3
    return math.abs(v1.X - v2.X) < epsilon and math.abs(v1.Y - v2.Y) < epsilon
end