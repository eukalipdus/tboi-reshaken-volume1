



function TSIL.GridSpecific.SpawnPoop(poopVariant, indexOrPosition, force)
    local gridEntity = TSIL.GridEntities.SpawnGridEntity(
        GridEntityType.GRID_POOP,
        poopVariant,
        indexOrPosition,
        force
    )

    if not gridEntity then return end

    local poop = gridEntity:ToPoop()
    if not poop then
        error("Failed to spawn a poop.")
    end

    return poop
end








