function TSIL.Doors.GetDoors(...)
    local possibleRoomTypes = {...}
    local room = Game():GetRoom()
    local doors = {}

    for i = 0, DoorSlot.NUM_DOOR_SLOTS-1, 1 do
        local door = room:GetDoor(i)

        if door and (#possibleRoomTypes == 0 or TSIL.Utils.Tables.IsIn(possibleRoomTypes, door.TargetRoomType)) then
            doors[#doors+1] = door
        end
    end

    return doors
end


function TSIL.Doors.GetDoorsToRoomIndex(...)
    local possibleRoomIndexes = {...}
    local room = Game():GetRoom()
    local doors = {}

    for i = 0, DoorSlot.NUM_DOOR_SLOTS-1, 1 do
        local door = room:GetDoor(i)

        if door and (#possibleRoomIndexes == 0 or TSIL.Utils.Tables.IsIn(possibleRoomIndexes, door.TargetRoomIndex)) then
            doors[#doors+1] = door
        end
    end

    return doors
end