function TSIL.Doors.RemoveDoor(door)
    local room = Game():GetRoom()
    room:RemoveDoor(door.Slot)
end


function TSIL.Doors.RemoveDoors(doors)
    for _, door in ipairs(doors) do
        TSIL.Doors.RemoveDoor(door)
    end
end

