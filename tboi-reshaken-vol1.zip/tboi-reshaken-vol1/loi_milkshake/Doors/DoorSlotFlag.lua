function TSIL.Doors.DoorSlotToDoorSlotFlag(doorSlot)
    return 1 << doorSlot
end




function TSIL.Doors.GetDoorSlotsFromDoorSlotBitMask(doorSlotBitMask)
    local doorSlots = {}

    for doorSlot = 0, DoorSlot.NUM_DOOR_SLOTS-1, 1 do
        if TSIL.Utils.Flags.HasFlags(doorSlotBitMask, TSIL.Doors.DoorSlotToDoorSlotFlag(doorSlot)) then
            doorSlots[#doorSlots+1] = doorSlot
        end
    end

    return doorSlots
end