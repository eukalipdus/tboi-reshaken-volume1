function TSIL.Color.GetRandomColor(seedOrRNG, alpha)
    seedOrRNG = seedOrRNG or TSIL.RNG.GetRandomSeed()

    local rng

    if TSIL.IsaacAPIClass.IsRNG(seedOrRNG) then
        rng = seedOrRNG
    else
        rng = TSIL.RNG.NewRNG(seedOrRNG)
    end

    local r = TSIL.Random.GetRandom(rng)
    local g = TSIL.Random.GetRandom(rng)
    local b = TSIL.Random.GetRandom(rng)

    return Color(r, g, b, alpha)
end
